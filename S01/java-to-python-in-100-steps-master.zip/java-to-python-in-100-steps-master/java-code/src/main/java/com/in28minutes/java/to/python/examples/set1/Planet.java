package com.in28minutes.java.to.python.examples.set1;

public class Planet {
	String name;

	public static void main(String[] args) {
		Planet earth = new Planet();
		earth.name = "Earth";

	}

}

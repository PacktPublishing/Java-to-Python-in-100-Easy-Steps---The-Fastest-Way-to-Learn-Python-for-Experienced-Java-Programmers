# print("Hello World")


def print_hello_world_twice():
    print("Hello World 1")
    print("Hello World 2")


def print_hello_world_multiple_times(times):
    for i in range(1, times+1):
        print("Hello World")


# print("Hello World 3")

# print_hello_world_twice()

print_hello_world_multiple_times(4)
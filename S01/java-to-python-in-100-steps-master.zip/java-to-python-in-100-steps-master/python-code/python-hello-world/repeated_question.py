number = int(input('Enter a number:'))

while number >= 0:
   print(f'cube is {number ** 3}')
   number = int(input('Enter a number:'))
